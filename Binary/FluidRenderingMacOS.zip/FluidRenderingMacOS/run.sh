CURRENT_PATH="$(pwd)/FluidRendering.app/Contents/MacOS"
FRAMEWORK_PATH="$(pwd)/FluidRendering.app/Contents/Frameworks"
export DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:$CURRENT_PATH:$FRAMEWORK_PATH

./FluidRendering.app/Contents/MacOS/FluidRendering
