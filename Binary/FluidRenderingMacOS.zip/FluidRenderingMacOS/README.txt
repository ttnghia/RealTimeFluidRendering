Please run the program in terminal, by running ./run.sh
